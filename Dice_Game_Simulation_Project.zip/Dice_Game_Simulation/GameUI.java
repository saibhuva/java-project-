package Dice_Game_Simulation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GameUI {
    private GameEngine engine;
    private JTextArea textArea;

    public GameUI(GameEngine engine) {
        this.engine = engine;

        JFrame frame = new JFrame("Dice Game Simulation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JButton playButton = new JButton("Play Round");
        textArea = new JTextArea();
        textArea.setEditable(false);

        playButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                engine.playRound();
                updateResults();
            }
        });

        frame.getContentPane().add(playButton, BorderLayout.NORTH);
        frame.getContentPane().add(new JScrollPane(textArea), BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private void updateResults() {
        StringBuilder sb = new StringBuilder();
        for (Player p : engine.arr) {
            sb.append(p.showName()).append(" has won ").append(p.showWins()).append(" rounds.\n");
        }
        textArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        ArrayList<Player> list = new ArrayList<>();
        list.add(new Player("Player1"));
        list.add(new Player("Player2"));
        GameEngine ge = new GameEngine(list);
        new GameUI(ge);
    }
}
